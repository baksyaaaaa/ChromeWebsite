Optional: jars placed here are copied into your mods folder on every launch with Fabric.
Chrome Client and YT Music are NOT needed here - the launcher downloads their newest
release from GitHub (baksyaaaaa/ChromeMod and baksyaaaaa/MusicMod) on its own.
