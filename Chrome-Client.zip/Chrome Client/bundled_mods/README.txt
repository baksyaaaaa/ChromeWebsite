Put the built mod jars here (chrome-client-*.jar and ytmusic-ingame-*.jar).
Every time you press Play with Fabric on, the launcher copies them into your mods folder
and replaces any older copy of the same mod. YT Music also needs Rinku, which the launcher
fetches as a dependency when it can.
