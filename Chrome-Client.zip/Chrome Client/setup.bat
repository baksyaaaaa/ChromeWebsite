@echo off
title Chrome Client setup
cd /d "%~dp0"
echo.
echo  Chrome Client setup
echo  -------------------
set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY goto nopython

echo Installing the newest version of everything the launcher needs...
%PY% -m pip install --upgrade pip
%PY% -m pip install --upgrade -r requirements.txt
if errorlevel 1 goto failed


echo Making a desktop shortcut...
%PY% make_shortcut.py --quiet

echo Starting Chrome Client...
if "%PY%"=="py" (start "" pyw start_chrome_client.pyw) else (start "" pythonw start_chrome_client.pyw)
exit /b 0

:nopython
echo Python isn't installed yet. Opening the download page.
echo Install it (tick "Add python.exe to PATH"), then run setup.bat again.
start https://www.python.org/downloads/
pause
exit /b 1

:failed
echo.
echo Something went wrong while installing. Check your internet connection and run setup.bat again.
pause
exit /b 1
